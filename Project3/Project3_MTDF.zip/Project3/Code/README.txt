Hello!

Thank you for downloading our project 3, Gentrificaton within the U.S.!

To run this program simply import the Jupyter notebook file (GentResearch_CS523) in Google Colab.
After importing the file, data sets must be imported now. We recommend making a folder on your personal Google Drive with all of your data sets.
Upon running, the application will ask you for access to your Google Drive to retrieve data from the folder.
Permission set and data retrieved and the program will now run smoothly with various sections of data cleaning and analysis.
Feel free to view all section to view how we implmented many different data analysis techniques.


Authors: Damian Franco and Meiling Traeger
Class: CS 423/523
Professor: Dr. Melanie Moses
Date: 5/6/2022